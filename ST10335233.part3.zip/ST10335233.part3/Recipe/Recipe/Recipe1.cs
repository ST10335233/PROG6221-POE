﻿using System;
using System.Collections.Generic;


namespace RecipeFilterApp
{
    public class Recipe1
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public double TotalCalories { get; private set; }

        public event Action<Recipe1, double> CaloriesExceeded;

        public Recipe1()
        {
            Ingredients = new List<Ingredient>();
        }

        public void EnterRecipeDetails()
        {
            // Example: Using MessageBox to gather recipe details
            Name = Microsoft.VisualBasic.Interaction.InputBox("Enter Recipe Name", "Recipe Details", "");

            // Example: Loop to add ingredients
            while (true)
            {
                string ingredientName = Microsoft.VisualBasic.Interaction.InputBox("Enter Ingredient Name (leave blank to finish)", "Ingredient Details", "");
                if (string.IsNullOrWhiteSpace(ingredientName))
                    break;

                double quantity = Convert.ToDouble(Microsoft.VisualBasic.Interaction.InputBox("Enter Quantity for " + ingredientName, "Ingredient Details", "0"));
                string foodGroup = Microsoft.VisualBasic.Interaction.InputBox("Enter Food Group for " + ingredientName, "Ingredient Details", "");

                Ingredients.Add(new Ingredient { Name = ingredientName, Quantity = quantity, FoodGroup = foodGroup });
            }

            CalculateTotalCalories();

            // Example: Check if total calories exceed limit and raise event if necessary
            if (TotalCalories > 300)
            {
                CaloriesExceeded?.Invoke(this, TotalCalories);
            }
        }

        public void ScaleRecipe(double factor)
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity *= factor;
            }

            CalculateTotalCalories();
        }

        public void ResetQuantities()
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity = 0;
            }

            CalculateTotalCalories();
        }

        public void ClearRecipe()
        {
            Name = "";
            Ingredients.Clear();
            TotalCalories = 0;
        }

        private void CalculateTotalCalories()
        {
            TotalCalories = 0;
            foreach (var ingredient in Ingredients)
            {
                // Assuming each ingredient contributes to total calories
                TotalCalories += ingredient.Quantity;
            }
        }

        internal void DisplayRecipe()
        {
            throw new NotImplementedException();
        }
    }

}
