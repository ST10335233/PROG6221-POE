﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace RecipeFilterApp
{
    public partial class MainWindow : Window
    {
        private List<Recipe1> recipes = new List<Recipe1>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void EnterRecipeDetails_Click(object sender, RoutedEventArgs e)
        {
            var newRecipe = new Recipe1();
            newRecipe.CaloriesExceeded += OnCaloriesExceeded;
            newRecipe.EnterRecipeDetails();
            recipes.Add(newRecipe);
            RefreshRecipeList();
        }

        private void OnCaloriesExceeded(Recipe1 sender, double totalCalories)
        {
            MessageBox.Show($"Warning: Total calories of recipe '{sender.Name}' exceed 300! Total calories: {totalCalories}");
        }

        private void DisplayAllRecipes_Click(object sender, RoutedEventArgs e)
        {
            RecipeListBox.ItemsSource = recipes.OrderBy(r => r.Name).ToList();
        }

        private void DisplaySpecificRecipe_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = RecipeNameTextBox.Text;
            var recipeToDisplay = recipes.FirstOrDefault(r => r.Name == recipeName);
            if (recipeToDisplay != null)
            {
                RecipeListBox.ItemsSource = new List<Recipe1> { recipeToDisplay };
            }
            else
            {
                MessageBox.Show("Recipe not found.");
            }
        }

        private void ScaleRecipe_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                double factor = Convert.ToDouble(ScaleFactorTextBox.Text);
                if (factor != 0.5 && factor != 2 && factor != 3)
                {
                    throw new FormatException("Invalid scale factor. Please enter 0.5, 2, or 3.");
                }
                string recipeName = RecipeNameTextBox.Text;
                var recipeToScale = recipes.FirstOrDefault(r => r.Name == recipeName);
                if (recipeToScale != null)
                {
                    recipeToScale.ScaleRecipe(factor);
                }
                else
                {
                    MessageBox.Show("Recipe not found.");
                }
            }
            catch (FormatException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void ResetQuantities_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = RecipeNameTextBox.Text;
            var recipeToReset = recipes.FirstOrDefault(r => r.Name == recipeName);
            if (recipeToReset != null)
            {
                recipeToReset.ResetQuantities();
            }
            else
            {
                MessageBox.Show("Recipe not found.");
            }
        }

        private void ClearRecipe_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = RecipeNameTextBox.Text;
            var recipeToClear = recipes.FirstOrDefault(r => r.Name == recipeName);
            if (recipeToClear != null)
            {
                recipeToClear.ClearRecipe();
            }
            else
            {
                MessageBox.Show("Recipe not found.");
            }
        }

        private void FilterButton_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(IngredientTextBox.Text))
            {
                string ingredientName = IngredientTextBox.Text;
                var filteredByIngredient = recipes.Where(r => r.Ingredients.Any(i => i.Name.Equals(ingredientName, StringComparison.OrdinalIgnoreCase)));
                DisplayFilteredRecipes(filteredByIngredient);
            }
            else if (FoodGroupComboBox.SelectedItem != null)
            {
                string foodGroup = (FoodGroupComboBox.SelectedItem as ComboBoxItem).Content.ToString();
                var filteredByFoodGroup = recipes.Where(r => r.Ingredients.Any(i => i.FoodGroup.Equals(foodGroup, StringComparison.OrdinalIgnoreCase)));
                DisplayFilteredRecipes(filteredByFoodGroup);
            }
            else if (double.TryParse(MaxCaloriesTextBox.Text, out double maxCalories))
            {
                var filteredByCalories = recipes.Where(r => r.TotalCalories <= maxCalories);
                DisplayFilteredRecipes(filteredByCalories);
            }
            else
            {
                MessageBox.Show("Please provide a valid filter criteria.");
            }
        }

        private void DisplayFilteredRecipes(IEnumerable<Recipe1> filteredRecipes)
        {
            if (!filteredRecipes.Any())
            {
                MessageBox.Show("No recipes match the filter criteria.");
            }
            else
            {
                RecipeListBox.ItemsSource = filteredRecipes.OrderBy(r => r.Name).ToList();
            }
        }

        private void RefreshRecipeList()
        {
            RecipeListBox.ItemsSource = null;
            RecipeListBox.ItemsSource = recipes.OrderBy(r => r.Name).ToList();
        }

        private void CreateMenu_Click(object sender, RoutedEventArgs e)
        {
            var menuRecipes = FilterMenuRecipes(recipes);
            DisplayMenu(menuRecipes);
        }

        private List<Recipe1> FilterMenuRecipes(List<Recipe1> recipes)
        {
            List<Recipe1> filteredRecipes = new List<Recipe1>();

            // Example filtering based on ingredient name
            if (!string.IsNullOrEmpty(IngredientTextBox.Text))
            {
                string ingredientName = IngredientTextBox.Text;
                filteredRecipes = recipes.Where(r => r.Ingredients.Any(i => i.Name.Equals(ingredientName, StringComparison.OrdinalIgnoreCase))).ToList();
            }
            // Add more conditions based on your filtering criteria (e.g., food group, max calories)

            return filteredRecipes;
        }

        private void DisplayMenu(List<Recipe1> menuRecipes)
        {
            if (menuRecipes.Count == 0)
            {
                MessageBox.Show("No recipes match the menu criteria.");
            }
            else
            {
                MessageBox.Show("Menu:");
                foreach (var recipe in menuRecipes)
                {
                    // Assuming you have a DisplayRecipe method in your Recipe1 class
                    recipe.DisplayRecipe();
                }
            }
        }
    }
}
