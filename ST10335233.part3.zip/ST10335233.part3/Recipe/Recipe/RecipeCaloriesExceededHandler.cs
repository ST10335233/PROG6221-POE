﻿namespace RecipeFilterApp
{
    public delegate void RecipeCaloriesExceededHandler(Recipe1 sender, double totalCalories);
}
