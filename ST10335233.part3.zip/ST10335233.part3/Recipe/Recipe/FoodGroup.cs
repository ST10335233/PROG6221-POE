﻿using System;
public enum FoodGroup
{
    Vegetables,
    Fruits,
    Grains,
    Protein,
    Dairy
}
